<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<html>
<head>
    <title>${courseName}</title>
</head>
<body>
<h1>${courseName}</h1>
<p>${courseDescription}</p>

<h2>Lectures</h2>
<c:forEach var="lecture" items="${lectures}">
    <div>${lecture}</div>
</c:forEach>

<h2>Polls</h2>
<c:forEach var="poll" items="${polls}">
    <b>${poll.question}</b>
    <ul>
        <c:forEach var="option" items="${poll.options}">
            <li>${option}</li>
        </c:forEach>
    </ul>
</c:forEach>
</body>
</html>
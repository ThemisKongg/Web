package hkmu.wadd.coursewebsite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseWebsiteApplication {
    public static void main(String[] args) {
        SpringApplication.run(CourseWebsiteApplication.class, args);
    }
}
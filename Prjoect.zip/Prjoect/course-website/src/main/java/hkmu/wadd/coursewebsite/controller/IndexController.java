package hkmu.wadd.coursewebsite.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;
import java.util.Map;

@Controller
public class IndexController {

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("courseName", "Web Applications: Design And Development");
        model.addAttribute("courseDescription", "Website Development");

        List<String> lectures = List.of("Lecture 1", "Lecture 2", "Lecture 3","Lecture 4", "Lecture 5");
        model.addAttribute("lectures", lectures);

        List<Map<String, Object>> polls = List.of(
                Map.of("question", "Which topic next?", "options", List.of("Graphs","Sorting","Recursion","OOP","Databases"))
        );
        model.addAttribute("polls", polls);

        return "index"; // points to index.jsp
    }
}